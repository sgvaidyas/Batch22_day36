function myfun()
{
    var fn = document.getElementById("fname").value;
    
    var ln = document.getElementById("lname").value;

    var per= document.getElementById("per").value;

   // console.log(fn + " " + ln + " " + per)
   dataelements = [fn,ln,per]
   console.log(dataelements)

   var tab = document.getElementById("details")
   var row = document.createElement("tr");

   for(x of dataelements)
   {
        var cNode =  document.createElement("td");
        var ctext = document.createTextNode(x);

        cNode.appendChild(ctext);//<td>Shilpa</td>
        row.appendChild(cNode);
   }
   tab.appendChild(row)
}