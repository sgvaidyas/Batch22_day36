function add()
{
    var a = document.getElementById("num1").value;
    var b = document.getElementById("num2").value;

    sum = parseInt(a)+ parseInt(b)
   // alert(sum)
    document.getElementById("addres").innerHTML = "SUM  = "+ sum;
}
function sub()
{
    var a = document.getElementById("num1").value;
    var b = document.getElementById("num2").value;

    res = parseInt(a)- parseInt(b)
   // alert(sum)
    document.getElementById("subres").innerHTML = "DIFFERENCE  = "+ res;
}

function mul()
{
    var a = document.getElementById("num1").value;
    var b = document.getElementById("num2").value;

    res = parseInt(a)* parseInt(b)
   // alert(sum)
    document.getElementById("subres").innerHTML = "PRODUCT    = "+ res;
}

function div()
{
    var a = document.getElementById("num1").value;
    var b = document.getElementById("num2").value;

    res = parseInt(a)/ parseInt(b)
   // alert(sum)
    document.getElementById("subres").innerHTML = "QUOTIENT  = "+ res;
}