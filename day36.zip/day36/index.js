function add()
{
    var a = 33;
    var b = 44;
    var sum=a+b;
    alert("sum = " + sum);
}

function message(name)
{
    var msg = "Welcome to javascript "+ name
    alert(msg)
}
function mydata()
{
    a=111;
    b="some string";
    c=77.88
    d='fffff'
    var e;
    console.log(typeof(a));
    console.log(typeof(b));
    console.log(typeof(c));
    console.log(typeof(d));
    console.log(typeof(e));
    
}

function func1()
{
    var s="apple";
    var s="help";
    console.log(s)

    let x = 88;
    console.log(x);
    x=99
    console.log(x);

}

function func2()
{
    var x= 5;
    {
        var x=4;
        console.log(x);
    }
    console.log(x);

    let y= 5;
    {
        let y=4;
        console.log(y);
    }
    console.log(y);
}
function func3()
{
    const x=99
    console.log(x)
    x=88 //gives error
}
function func4()
{
    var x = 44/3
    var y = parseInt(44/3)
    var z = 2**4
    console.log(x)
    console.log(y)
    console.log(z)    
}

function func5()
{
    var a = [11,22,33,"apple","mango"]

    console.log("normal for loop")

    for(var i=0;i<a.length;i++)
        console.log(a[i])

    console.log("using foreach loop")

    a.forEach(myarr);
}
function myarr(value)
{
    console.log(value)
}

function func6()
{
    var a= [11,22,33,44,55]
    console.log("using for in loop")
    for(x in a)
        console.log(x + "=" + a[x])


    var myvar = "JungleBook";

    for(x of myvar)
        console.log(x)

    for(x of a)
        console.log(x)

}

function func7(num)
{
    if(num<=100 && num>=60)
        console.log("distinction")
    else if(num<=59 && num>=40)
        console.log("pass")
    else
        console.log("fail")

}
function func8(val)
{
    switch(val)
    {
        case "RED":
        case "red":console.log("STOP");break;
        case "GREEN":
        case "green":console.log("MOVE");break;
        case "YELLOW":
        case "yellow":console.log("START");break;
        default:console.log("Invalid");break;
        
    }
}

function func9()
{
    var a=["apple","grapes","jackfruit"]
    myvar = a.join("***")
    console.log(myvar)
}
function func10()
{
    a = [11,22,33,44]
    console.log("shift = "+ a.shift())
    console.log(a)
    console.log("a.unshift(777) = "+ a.unshift(777))
    console.log(a)
    console.log("a.unshift(888) = "+ a.unshift(888))
    console.log(a)
    console.log("a.pop() = "+ a.pop())
    console.log(a)
    console.log("a.push(999) = "+a.push(999))
    console.log(a)
    delete a[3]
    console.log(a)
    for (x of a)
        console.log(x)
    //no matter what is given as parameter in .pop-> will delete the last ele
    console.log("a.pop(2)="+a.pop(2))
    
}
function func11()
{
    a=[11,2,3,44,55,66,77,88,99,100]
    console.log(a)
    x=a.splice(2,5)
    console.log("A = "+a)
    console.log("X = "+x)

    a=[1,2,3]
    b=[11,22,33]
    c= a+b
    d=a.concat(b)
    console.log(c)
    console.log(typeof(c))
    console.log(d)
}